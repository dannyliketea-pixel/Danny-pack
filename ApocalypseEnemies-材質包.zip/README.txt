ApocalypseEnemies 材質包：人型敵人（感染者、掠奪者）的皮膚。
伺服器 config.yml 的 appearance.skin-mode 設為 resource-pack 時使用（預設）。
可以和 ApocalypseCombat 武器材質包、聚落材質包一起安裝。
皮膚檔案：assets/apocalypse_en/textures/entity/skins/*.png（64x64 玩家皮膚格式，可自行替換）
