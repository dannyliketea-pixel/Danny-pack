===== en =====
ApocalypseEnemies 材質包：人型敵人（感染者、掠奪者）的皮膚。
伺服器 config.yml 的 appearance.skin-mode 設為 resource-pack 時使用（預設）。
可以和 ApocalypseCombat 武器材質包、聚落材質包一起安裝。
皮膚檔案：assets/apocalypse_en/textures/entity/skins/*.png（64x64 玩家皮膚格式，可自行替換）


===== meta =====
末日伺服器 合併材質包（一個 zip 包含全部）
- ApocalypseCombat 1.8.0 武器／彈藥／醫療／裝備欄模型與望遠鏡分劃（命名空間 apocalypse，另有 minecraft:textures/misc/spyglass_scope.png 分劃）
- ApocalypseSettlements 1.5.0 聚落物品與工作台模型（命名空間 apocalypse_st，97 個模型）
- ApocalypseEnemies 1.0.0 敵人皮膚（命名空間 apocalypse_en）
兩個版本只差在望遠鏡／瞄準鏡分劃：樹狀準星 或 紅點準星，選一個即可。
由 merge.py 產生：各插件使用不同命名空間，沒有檔案互相覆蓋；pack.mcmeta 與 pack.png 為重新產生。
